#include "Show.h"

using namespace std;

void Menu(){
    system("clear");
    cout << "1 - Cadastrar\n";
    cout << "2 - Excluir\n";
    cout << "3 - Listar\n";
    cout << "4 - Maior Publico\n";
    cout << "5 - Maior Lucro\n";
    cout << "6 - Sair\n";
    cout << "Escolha: ";
}

int main()
{
    Show *Topo = NULL, p;
    string nome, local;
    int publico, op;
    float ingresso, cache;
    do{
        Menu();
        cin >> op;
        switch(op){
            case 1:
                cout << "Informe nome: ";
                cin.ignore();
                getline(cin, nome);
                cout << "Informe o local: ";
                getline(cin, local);
                cout << "Informe o publico: ";
                cin >> publico;
                cout << "Informe o ingresso: ";
                cin >> ingresso;
                cout << "Informe o cache: ";
                cin >> cache;
                Topo = p.Inserir(Topo, nome, local, publico, ingresso, cache);
                cout << "Inserido!!!!!\n";
                break;
            case 2:
                if(Topo != NULL){
                    Topo = p.Excluir(Topo);
                    cout << "Excluido!!!!\n";
                }else{
                    cout << "Pilha vazia!!!\n";
                }
                break;
            case 3:
                if(Topo != NULL){
                    cout << "Listagem\n";
                    p.Listar(Topo);
                }else{
                    cout << "Pilha vazia!!!\n";
                }
                break;
            case 4:
                if(Topo != NULL){
                    cout << "Maior Publico\n";
                    p.MostrarMaiorPublico(Topo, p.MaiorPublico(Topo));
                }else{
                    cout << "Pilha vazia!!!\n";
                }
                break;
            case 5:
                if(Topo != NULL){
                    cout << "Maior Lucro\n";
                    p.MostrarMaiorLucro(Topo, p.MaiorLucro(Topo));
                }else{
                    cout << "Pilha vazia!!!\n";
                }
                break;
            case 6:
                cout << "Tchau!!!\n";
                break;
            default:
                cout << "Errado!!!\n";
        }
        cin.ignore().get();
    }while(op != 6);
    return 0;
}
