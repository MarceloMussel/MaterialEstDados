#include "Show.h"

Show* Show::Inserir(Show *T, std::string N, std::string L, int P, float I, float C){
    Show *novo = new Show();
    novo->Nome = N;
    novo->Local = L;
    novo->Publico = P;
    novo->Ingresso = I;
    novo->Cache = C;
    novo->elo = T;
    T = novo;
    return T;
};
Show* Show::Excluir(Show *T){
    Show *aux = T;
    T = T->elo;
    delete(aux);
    return T;
};
void Show::Listar(Show *T){
    Show *aux = T;
    while(aux != NULL){
        std::cout << aux->Nome << "  " << aux->Local << " " << aux->Publico << " " << aux->Ingresso << " " << aux->Cache << std::endl;
        aux = aux->elo;
    }
};
int Show::MaiorPublico(Show *T){
    Show *aux = T;
    int Maior = aux->Publico;
    aux = aux->elo;
    while(aux != NULL){
        if(aux->Publico > Maior){
            Maior = aux->Publico;
        }
        aux = aux->elo;
    }
    return Maior;
};
void Show::MostrarMaiorPublico(Show *T, int M){
    Show *aux = T;
    while(aux != NULL){
        if(aux->Publico == M){
            std::cout << aux->Nome << "  " << aux->Local << " " << aux->Publico << " " << aux->Ingresso << " " << aux->Cache << std::endl;
        }
        aux = aux->elo;
    }
};
float Show::MaiorLucro(Show *T){
    Show *aux = T;
    float M = aux->Publico * aux->Ingresso - aux->Cache;
    aux = aux->elo;
    while(aux != NULL){
        if((aux->Publico * aux->Ingresso - aux->Cache) > M){
            M = aux->Publico * aux->Ingresso - aux->Cache;
        }
        aux = aux->elo;
    }
    return M;
};
void Show::MostrarMaiorLucro(Show *T, float M){
    Show *aux = T;
    while(aux != NULL){
        if((aux->Publico * aux->Ingresso - aux->Cache) == M){
            std::cout << aux->Nome << "  " << aux->Local << " " << aux->Publico << " " << aux->Ingresso << " " << aux->Cache << std::endl;
        }
        aux = aux->elo;
    }
};








