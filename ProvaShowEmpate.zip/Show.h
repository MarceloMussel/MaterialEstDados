#include <iostream>
class Show
{
    public:
        std::string Nome, Local;
        int Publico;
        float Ingresso, Cache;
        Show *elo;
        Show* Inserir(Show*, std::string, std::string, int, float, float);
        Show* Excluir(Show*);
        void Listar(Show*);
        int MaiorPublico(Show*);
        void MostrarMaiorPublico(Show*, int);
        float MaiorLucro(Show*);
        void MostrarMaiorLucro(Show*, float);
};
