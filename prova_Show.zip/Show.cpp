#include "Show.h"

Show* Show::Inserir(Show *T, std::string N, std::string L, int P, float V, float C){
    Show *novo = new Show();
    novo->Nome = N;
    novo->Local = L;
    novo->Publico = P;
    novo->Ingresso = V;
    novo->Cache = C;
    novo->elo = T;
    T = novo;
    return T;
};
Show* Show::Excluir(Show *T){
    Show *aux = T;
    T = T->elo;
    delete(aux);
    return T;
};
void Show::Listar(Show *T){
    Show *aux = T;
    while(aux != NULL){
        std::cout << aux->Nome << " " << aux->Local << " " << aux->Publico << " " << aux->Ingresso << " " << aux->Cache << std::endl;
        aux = aux->elo;
    }
};
Show* Show::MaiorPublico(Show *T){
    Show *Maior = T;
    Show *aux = T->elo;
    while(aux != NULL){
        if(aux->Publico > Maior->Publico){
            Maior = aux;
        }
        aux = aux->elo;
    }
    return Maior;
};
Show* Show::MaiorLucro(Show *T){
    Show *Maior = T;
    Show *aux = T->elo;
    while(aux != NULL){
        if((aux->Publico * aux->Ingresso - aux->Cache) > (Maior->Publico * Maior->Ingresso - Maior->Cache)){
            Maior = aux;
        }
        aux = aux->elo;
    }
    return Maior;
}











;
