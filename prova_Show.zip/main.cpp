#include "Show.h"

using namespace std;

void Menu(){
    system("clear");
    cout << "1 - Cadastrar Show\n";
    cout << "2 - Excluir Show\n";
    cout << "3 - Listagem Geral\n";
    cout << "4 - maior plateia\n";
    cout << "5 - maior lucro\n";
    cout << "6 - Sair\n";
    cout << "Escolha: ";
}

int main()
{
    Show *Topo = NULL, *M, p;
    string nome, local;
    int publico, op;
    float ingresso, cache;
    do{
        Menu();
        cin >> op;
        switch(op){
            case 1:
                cout << "Informe o Nome: ";
                cin.ignore();
                getline(cin, nome);
                cout << "Informe o local: ";
                getline(cin, local);
                cout << "Informe publico: ";
                cin >> publico;
                cout << "Informe o ingresso: ";
                cin >> ingresso;
                cout << "Informe o cache: ";
                cin >> cache;
                Topo = p.Inserir(Topo, nome, local, publico, ingresso, cache);
                cout << "Inserido!!!!\n";
                break;
            case 2:
                if(Topo != NULL){
                    Topo = p.Excluir(Topo);
                    cout << "Excluido!!\n";
                }else{
                    cout << "Pilha vazia!!\n";
                }
                break;
            case 3:
                if(Topo != NULL){
                    cout << "Listagem\n";
                    p.Listar(Topo);
                }else{
                    cout << "Pilha vazia!!\n";
                }
                break;
            case 4:
                if(Topo != NULL){
                    M = p.MaiorPublico(Topo);
                    cout << "Maior Publico: ";
                    cout << M->Nome << " " << M->Local << " " << M->Publico << " " << M->Ingresso << " " << M->Cache << endl;
                }else{
                    cout << "Pilha vazia!!\n";
                }
                break;
            case 5:
            if(Topo != NULL){
                    M = p.MaiorLucro(Topo);
                    cout << "Maior Lucro: ";
                    cout << M->Nome << " " << M->Local << " " << M->Publico << " " << M->Ingresso << " " << M->Cache << endl;
                }else{
                    cout << "Pilha vazia!!\n";
                }
                break;
            case 6:
                cout << "Tchau!!!\n";
                break;
            default:
                cout << "Errado\n";
        }
        cin.ignore().get();
    }while(op != 6);
    return 0;
}
